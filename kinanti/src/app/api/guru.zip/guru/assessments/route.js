import { NextResponse } from "next/server";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();
export async function POST(req) {
  try {
    const body = await req.json();
    const { guruId, kode, title, className, timeClose } = body || {};

    if (!guruId || !kode || !title || !className) {
      return NextResponse.json(
        { ok: false, message: "Data tidak lengkap." },
        { status: 400 }
      );
    }

    const created = await prisma.assessment.create({
      data: {
        guruId: Number(guruId),
        code: String(kode).toUpperCase(),
        title: title,
        className: String(className).toUpperCase(),
        timeClose: timeClose ? new Date(timeClose) : null,
        status: "DRAFT",
        kkm: 75,
        shuffleQuestions: true,
        shuffleOptions: true,
        maxAttempts: 1,
        showScoreImmediately: true,
        showKeyAfterClose: false,
      },
    });

    return NextResponse.json({
      ok: true,
      data: { id: created.id, code: created.code },
    });
  } catch (e) {
    console.error(e);
    return NextResponse.json(
      { ok: false, message: "Gagal membuat assessment." },
      { status: 500 }
    );
  }
}
