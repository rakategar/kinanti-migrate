export const runtime = "nodejs"; // penting untuk Prisma
export const dynamic = "force-dynamic"; // optional, biar no cache

import { NextResponse } from "next/server";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

export async function GET(_req, ctx) {
  try {
    const { code } = await ctx.params; // ⬅️ params harus di-await
    const decoded = decodeURIComponent(code);

    const assessment = await prisma.assessment.findUnique({
      where: { code: decoded },
    });
    if (!assessment) {
      return NextResponse.json(
        { ok: false, message: "Assessment tidak ditemukan" },
        { status: 404 }
      );
    }

    const qs = await prisma.question.findMany({
      where: { assessmentId: assessment.id },
      orderBy: { id: "asc" },
      include: { options: { include: { media: true } }, media: true },
    });

    const questions = qs.map((q) => ({
      id: q.id,
      text: q.text,
      answerKeyLabel: q.answerKeyId
        ? q.options.find((o) => o.id === q.answerKeyId)?.label || null
        : null,
      media: q.media,
      options: q.options.map((o) => ({
        id: o.id,
        label: o.label,
        text: o.text,
        media: o.media,
      })),
      imageUrl: q.media?.[0]?.url ?? null,
    }));

    return NextResponse.json({ ok: true, data: { assessment, questions } });
  } catch (e) {
    console.error(e);
    return NextResponse.json(
      { ok: false, message: "Gagal memuat assessment." },
      { status: 500 }
    );
  }
}

export async function PUT(req, ctx) {
  try {
    const { code } = await ctx.params;
    const decoded = decodeURIComponent(code);
    const body = await req.json().catch(() => ({}));
    const { action } = body || {};

    const assessment = await prisma.assessment.findUnique({
      where: { code: decoded },
    });
    if (!assessment)
      return NextResponse.json(
        { ok: false, message: "Assessment tidak ditemukan" },
        { status: 404 }
      );

    if (action === "finish") {
      await prisma.assessment.update({
        where: { id: assessment.id },
        data: {},
      });
      return NextResponse.json({ ok: true });
    }

    return NextResponse.json(
      { ok: false, message: "Aksi tidak dikenali" },
      { status: 400 }
    );
  } catch (e) {
    console.error(e);
    return NextResponse.json(
      { ok: false, message: "Gagal update assessment." },
      { status: 500 }
    );
  }
}

export async function DELETE(_req, ctx) {
  try {
    const { code } = await ctx.params;
    const decoded = decodeURIComponent(code);
    const assessment = await prisma.assessment.findUnique({
      where: { code: decoded },
    });
    if (!assessment) return NextResponse.json({ ok: true });
    await prisma.assessment.delete({ where: { id: assessment.id } });
    return NextResponse.json({ ok: true });
  } catch (e) {
    console.error(e);
    return NextResponse.json(
      { ok: false, message: "Gagal menghapus assessment." },
      { status: 500 }
    );
  }
}
